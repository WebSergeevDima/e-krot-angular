export const environment = {
  production: true,
  serverUrl: 'http://e-krot.etalonocenki.com/api/web'
};
