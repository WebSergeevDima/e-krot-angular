import { Component, OnInit } from '@angular/core';
import { RolesService } from '../shared/services/roles.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {



  constructor(
    private roles: RolesService,
  ) {
  }

  ngOnInit(): void {
  }

  privilege(privelege: string): boolean {
    return this.roles.validatePrivilege(privelege)
  }

  scrollingToAssessment() {

    const assessment = document.querySelector('[data-block="assessment"]')

    assessment.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    })

  }

}
